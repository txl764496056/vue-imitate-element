<template>
  <div>
    首页内容
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style lang="scss" scoped>

</style>