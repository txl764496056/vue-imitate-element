<template>
    <div>
        ImOptionGroup
    </div>
</template>

<script>
    export default {
        name:'ImOptionGroup'
    }
</script>

<style lang="scss" scoped>

</style>