import ImScrollbar from './im-main';

export default ImScrollbar;