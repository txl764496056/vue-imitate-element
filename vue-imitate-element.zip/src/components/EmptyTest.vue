<template>
    <div>
            <slot></slot>
    </div>
</template>

<script>
    export default {
        name:"EmptyTest"
    }
</script>

<style lang="scss" scoped>

</style>